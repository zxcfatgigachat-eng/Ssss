import Link from "next/link";

export default function Footer() {
  return (
    <footer className="bg-[#1A0F0A] text-[#D4B896] border-t border-[#3D2419]">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 py-10">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <div className="flex items-center gap-2 mb-3">
              <span className="text-2xl">☕</span>
              <span className="text-lg font-bold text-[#F5E6D3]">Арома</span>
            </div>
            <p className="text-sm leading-relaxed text-[#A89078]">
              Кофейня, где каждый день начинается с аромата свежеобжаренных
              зёрен и тёплой атмосферы.
            </p>
          </div>

          <div>
            <h3 className="text-[#F5E6D3] font-semibold mb-3">Навигация</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/" className="hover:text-[#E8C9A0] transition-colors">
                  Главная
                </Link>
              </li>
              <li>
                <Link
                  href="/menu"
                  className="hover:text-[#E8C9A0] transition-colors"
                >
                  Меню
                </Link>
              </li>
              <li>
                <Link
                  href="/about"
                  className="hover:text-[#E8C9A0] transition-colors"
                >
                  О нас
                </Link>
              </li>
              <li>
                <Link
                  href="/location"
                  className="hover:text-[#E8C9A0] transition-colors"
                >
                  Где нас найти
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-[#F5E6D3] font-semibold mb-3">Контакты</h3>
            <ul className="space-y-2 text-sm text-[#A89078]">
              <li>ул. Кофейная, 15</li>
              <li>Москва</li>
              <li>
                <a
                  href="tel:+74951234567"
                  className="hover:text-[#E8C9A0] transition-colors"
                >
                  +7 (495) 123-45-67
                </a>
              </li>
              <li>
                <a
                  href="mailto:hello@aroma.coffee"
                  className="hover:text-[#E8C9A0] transition-colors"
                >
                  hello@aroma.coffee
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-8 pt-6 border-t border-[#3D2419] text-center text-xs text-[#7A6550]">
          © {new Date().getFullYear()} Кофейня «Арома». Все права защищены.
        </div>
      </div>
    </footer>
  );
}
