import Image from "next/image";

export default function AboutPage() {
  return (
    <div>
      <section className="bg-gradient-to-b from-[#2C1810] to-[#4A2F23] py-16 md:py-20">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 text-center">
          <h1 className="text-3xl md:text-4xl font-bold text-[#F5E6D3] mb-4">
            О нас
          </h1>
          <p className="text-[#D4B896] max-w-2xl mx-auto text-lg">
            Кофейня «Арома» — это место, где рождается настоящий кофейный вкус
          </p>
        </div>
      </section>

      <section className="max-w-6xl mx-auto px-4 sm:px-6 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div className="relative aspect-[4/3] rounded-2xl overflow-hidden shadow-xl">
            <Image
              src="https://images.unsplash.com/photo-1442512595331-e89e73853f31?w=800&h=600&fit=crop"
              alt="Интерьер кофейни"
              fill
              className="object-cover"
              sizes="(max-width: 768px) 100vw, 50vw"
            />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-[#2C1810] mb-4">
              Наша история
            </h2>
            <p className="text-[#6B4423] leading-relaxed mb-4">
              Всё началось в 2019 году с простой идеи: создать пространство,
              где можно не просто выпить кофе, а почувствовать его настоящий
              характер. Мы начали с маленькой обжарочной и стойки на углу
              уютного двора.
            </p>
            <p className="text-[#6B4423] leading-relaxed">
              Сегодня «Арома» — это команда единомышленников, собственные
              рецептуры и гости, которые становятся друзьями. Мы по-прежнему
              обжариваем зёрна небольшими партиями и готовим каждую чашку так,
              будто это первая.
            </p>
          </div>
        </div>
      </section>

      <section className="bg-[#F5E6D3]/50 py-16">
        <div className="max-w-6xl mx-auto px-4 sm:px-6">
          <h2 className="text-2xl font-bold text-[#2C1810] text-center mb-10">
            Наши ценности
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-8">
            {[
              {
                title: "Качество зёрен",
                text: "Мы работаем напрямую с фермерами и выбираем только те лоты, которые соответствуют нашим стандартам вкуса и этики.",
              },
              {
                title: "Честность вкуса",
                text: "Никаких лишних добавок и маскировки. Мы раскрываем природный профиль каждого сорта — кислотность, сладость, послевкусие.",
              },
              {
                title: "Забота о гостях",
                text: "Каждый гость важен. Мы помним предпочтения, советуем новые напитки и всегда рады помочь с выбором.",
              },
            ].map((v) => (
              <div
                key={v.title}
                className="bg-white rounded-2xl p-6 shadow-md border border-[#E8D5C4]"
              >
                <h3 className="text-lg font-semibold text-[#2C1810] mb-2">
                  {v.title}
                </h3>
                <p className="text-sm text-[#6B4423] leading-relaxed">
                  {v.text}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="max-w-6xl mx-auto px-4 sm:px-6 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div className="order-2 md:order-1">
            <h2 className="text-2xl font-bold text-[#2C1810] mb-4">
              Подход к приготовлению
            </h2>
            <p className="text-[#6B4423] leading-relaxed mb-4">
              Мы используем профессиональное оборудование и тщательно
              контролируем каждый параметр: температуру воды, степень помола,
              время экстракции. Для эспрессо — 9 бар, 25–30 секунд. Для
              альтернативы — точные пропорции и свежий помол.
            </p>
            <p className="text-[#6B4423] leading-relaxed">
              Молоко взбиваем до бархатистой микро-пены, а сиропы и топпинги
              готовим сами. Результат — стабильный вкус, которым можно
              наслаждаться каждый день.
            </p>
          </div>
          <div className="relative aspect-[4/3] rounded-2xl overflow-hidden shadow-xl order-1 md:order-2">
            <Image
              src="https://images.unsplash.com/photo-1511920170033-f8396924c348?w=800&h=600&fit=crop"
              alt="Бариста готовит кофе"
              fill
              className="object-cover"
              sizes="(max-width: 768px) 100vw, 50vw"
            />
          </div>
        </div>
      </section>
    </div>
  );
}
