import Link from "next/link";
import Image from "next/image";

export default function Home() {
  return (
    <div>
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-[#2C1810] via-[#4A2F23] to-[#6B4423]" />
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-10 left-10 w-40 h-40 rounded-full bg-[#C4A484] blur-3xl" />
          <div className="absolute bottom-20 right-20 w-60 h-60 rounded-full bg-[#8B5A2B] blur-3xl" />
        </div>

        <div className="relative max-w-6xl mx-auto px-4 sm:px-6 py-20 md:py-28 flex flex-col md:flex-row items-center gap-12">
          <div className="flex-1 text-center md:text-left">
            <p className="text-[#E8C9A0] text-sm font-medium tracking-widest uppercase mb-3">
              Добро пожаловать
            </p>
            <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold text-[#F5E6D3] leading-tight mb-4">
              Кофейня «Арома»
            </h1>
            <p className="text-lg md:text-xl text-[#D4B896] max-w-lg mb-8 leading-relaxed">
              Где каждая чашка — маленькое путешествие. Свежеобжаренный кофе,
              уютная атмосфера и любовь к деталям.
            </p>
            <Link
              href="/menu"
              className="inline-flex items-center gap-2 bg-[#E8C9A0] text-[#2C1810] font-semibold px-8 py-3.5 rounded-full hover:bg-[#F5E6D3] transition-colors shadow-lg hover:shadow-xl"
            >
              Смотреть меню
              <svg
                className="w-5 h-5"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M17 8l4 4m0 0l-4 4m4-4H3"
                />
              </svg>
            </Link>
          </div>

          <div className="flex-1 w-full max-w-md">
            <div className="relative aspect-[4/3] rounded-2xl overflow-hidden shadow-2xl border-4 border-[#5C3A2E]/50">
              <Image
                src="https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?w=800&h=600&fit=crop"
                alt="Чашка кофе в уютной кофейне"
                fill
                className="object-cover"
                priority
                sizes="(max-width: 768px) 100vw, 500px"
              />
            </div>
          </div>
        </div>
      </section>

      <section className="max-w-6xl mx-auto px-4 sm:px-6 py-16 md:py-20">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-[#2C1810] mb-3">
            Почему выбирают нас
          </h2>
          <p className="text-[#6B4423] max-w-xl mx-auto">
            Мы верим, что хороший кофе способен сделать день лучше
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
          {[
            {
              icon: "🌱",
              title: "Свежая обжарка",
              text: "Зёрна обжариваем небольшими партиями прямо у нас, чтобы сохранить максимум вкуса и аромата.",
            },
            {
              icon: "👨‍🍳",
              title: "Мастера-бариста",
              text: "Наши бариста проходят обучение и постоянно совершенствуют рецептуры и техники приготовления.",
            },
            {
              icon: "🏠",
              title: "Уютное пространство",
              text: "Тёплый интерьер, мягкий свет и спокойная музыка — место, куда хочется возвращаться.",
            },
          ].map((item) => (
            <div
              key={item.title}
              className="bg-white rounded-2xl p-6 shadow-md border border-[#E8D5C4] hover:shadow-lg transition-shadow"
            >
              <div className="text-3xl mb-3">{item.icon}</div>
              <h3 className="text-lg font-semibold text-[#2C1810] mb-2">
                {item.title}
              </h3>
              <p className="text-sm text-[#6B4423] leading-relaxed">
                {item.text}
              </p>
            </div>
          ))}
        </div>
      </section>

      <section className="bg-[#2C1810] py-14">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 text-center">
          <h2 className="text-2xl md:text-3xl font-bold text-[#F5E6D3] mb-4">
            Готовы попробовать?
          </h2>
          <p className="text-[#D4B896] mb-6 max-w-md mx-auto">
            Загляните в меню — там вас ждут классика и фирменные напитки
          </p>
          <Link
            href="/menu"
            className="inline-flex items-center gap-2 border-2 border-[#E8C9A0] text-[#E8C9A0] font-semibold px-7 py-3 rounded-full hover:bg-[#E8C9A0] hover:text-[#2C1810] transition-colors"
          >
            Перейти в меню
          </Link>
        </div>
      </section>
    </div>
  );
}
