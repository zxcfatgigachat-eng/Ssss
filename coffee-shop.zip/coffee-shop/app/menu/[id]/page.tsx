import Link from "next/link";
import Image from "next/image";
import { notFound } from "next/navigation";
import { getMenuItem, categoryLabels } from "@/lib/menu-data";

type Props = {
  params: Promise<{ id: string }>;
};

export default async function MenuItemPage({ params }: Props) {
  const { id } = await params;
  const item = getMenuItem(id);

  if (!item) {
    notFound();
  }

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-12">
      <Link
        href="/menu"
        className="inline-flex items-center gap-2 text-[#8B5A2B] hover:text-[#2C1810] font-medium mb-8 transition-colors"
      >
        <svg
          className="w-5 h-5"
          fill="none"
          stroke="currentColor"
          viewBox="0 0 24 24"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M10 19l-7-7m0 0l7-7m-7 7h18"
          />
        </svg>
        Назад в меню
      </Link>

      <div className="bg-white rounded-3xl overflow-hidden shadow-lg border border-[#E8D5C4]">
        <div className="grid grid-cols-1 md:grid-cols-2">
          <div className="relative aspect-square md:aspect-auto md:min-h-[420px]">
            <Image
              src={item.image}
              alt={item.name}
              fill
              className="object-cover"
              sizes="(max-width: 768px) 100vw, 50vw"
              priority
            />
          </div>
          <div className="p-8 md:p-10 flex flex-col justify-center">
            <span className="text-sm font-medium text-[#8B5A2B] uppercase tracking-wider mb-2">
              {categoryLabels[item.category]}
            </span>
            <h1 className="text-3xl md:text-4xl font-bold text-[#2C1810] mb-4">
              {item.name}
            </h1>
            <p className="text-[#6B4423] leading-relaxed mb-6 text-lg">
              {item.description}
            </p>
            <div className="flex items-center gap-4">
              <span className="text-3xl font-bold text-[#8B5A2B]">
                {item.price} ₽
              </span>
            </div>
            <Link
              href="/menu"
              className="mt-8 inline-flex items-center justify-center gap-2 bg-[#2C1810] text-[#F5E6D3] font-semibold px-6 py-3 rounded-full hover:bg-[#4A2F23] transition-colors w-fit"
            >
              Назад в меню
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
