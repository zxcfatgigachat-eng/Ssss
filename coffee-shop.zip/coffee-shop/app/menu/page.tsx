import Link from "next/link";
import Image from "next/image";
import { menuItems, categoryLabels } from "@/lib/menu-data";

export default function MenuPage() {
  const categories = ["coffee", "tea", "dessert", "food"] as const;

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-12">
      <div className="text-center mb-12">
        <h1 className="text-3xl md:text-4xl font-bold text-[#2C1810] mb-3">
          Наше меню
        </h1>
        <p className="text-[#6B4423] max-w-lg mx-auto">
          Напитки и блюда, приготовленные с любовью из лучших ингредиентов
        </p>
      </div>

      {categories.map((cat) => {
        const items = menuItems.filter((i) => i.category === cat);
        if (items.length === 0) return null;
        return (
          <section key={cat} className="mb-14">
            <h2 className="text-xl font-semibold text-[#2C1810] mb-6 flex items-center gap-2">
              <span className="w-8 h-0.5 bg-[#8B5A2B]" />
              {categoryLabels[cat]}
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {items.map((item) => (
                <Link
                  key={item.id}
                  href={`/menu/${item.id}`}
                  className="group bg-white rounded-2xl overflow-hidden shadow-md border border-[#E8D5C4] hover:shadow-xl hover:-translate-y-1 transition-all duration-300"
                >
                  <div className="relative aspect-[4/3] overflow-hidden">
                    <Image
                      src={item.image}
                      alt={item.name}
                      fill
                      className="object-cover group-hover:scale-105 transition-transform duration-500"
                      sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
                    />
                  </div>
                  <div className="p-5">
                    <div className="flex items-start justify-between gap-2 mb-2">
                      <h3 className="font-semibold text-[#2C1810] group-hover:text-[#8B5A2B] transition-colors">
                        {item.name}
                      </h3>
                      <span className="text-[#8B5A2B] font-bold whitespace-nowrap">
                        {item.price} ₽
                      </span>
                    </div>
                    <p className="text-sm text-[#6B4423] line-clamp-2 leading-relaxed">
                      {item.description}
                    </p>
                  </div>
                </Link>
              ))}
            </div>
          </section>
        );
      })}
    </div>
  );
}
