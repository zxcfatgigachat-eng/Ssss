export default function LocationPage() {
  return (
    <div>
      <section className="bg-gradient-to-b from-[#2C1810] to-[#4A2F23] py-16 md:py-20">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 text-center">
          <h1 className="text-3xl md:text-4xl font-bold text-[#F5E6D3] mb-4">
            Где нас найти
          </h1>
          <p className="text-[#D4B896] max-w-2xl mx-auto text-lg">
            Ждём вас в самом сердце города
          </p>
        </div>
      </section>

      <section className="max-w-6xl mx-auto px-4 sm:px-6 py-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
          <div className="space-y-8">
            <div className="bg-white rounded-2xl p-6 shadow-md border border-[#E8D5C4]">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-full bg-[#F5E6D3] flex items-center justify-center text-2xl shrink-0">
                  📍
                </div>
                <div>
                  <h2 className="text-lg font-semibold text-[#2C1810] mb-1">
                    Адрес
                  </h2>
                  <p className="text-[#6B4423]">
                    ул. Кофейная, 15
                    <br />
                    Москва, 119019
                  </p>
                  <p className="text-sm text-[#8B5A2B] mt-2">
                    5 минут пешком от метро «Арбатская»
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-2xl p-6 shadow-md border border-[#E8D5C4]">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-full bg-[#F5E6D3] flex items-center justify-center text-2xl shrink-0">
                  🕐
                </div>
                <div>
                  <h2 className="text-lg font-semibold text-[#2C1810] mb-2">
                    Часы работы
                  </h2>
                  <ul className="space-y-1.5 text-[#6B4423]">
                    <li className="flex justify-between gap-4">
                      <span>Понедельник — Пятница</span>
                      <span className="font-medium">08:00 – 22:00</span>
                    </li>
                    <li className="flex justify-between gap-4">
                      <span>Суббота</span>
                      <span className="font-medium">09:00 – 23:00</span>
                    </li>
                    <li className="flex justify-between gap-4">
                      <span>Воскресенье</span>
                      <span className="font-medium">09:00 – 21:00</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-2xl p-6 shadow-md border border-[#E8D5C4]">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-full bg-[#F5E6D3] flex items-center justify-center text-2xl shrink-0">
                  📞
                </div>
                <div>
                  <h2 className="text-lg font-semibold text-[#2C1810] mb-2">
                    Контакты
                  </h2>
                  <ul className="space-y-2 text-[#6B4423]">
                    <li>
                      <a
                        href="tel:+74951234567"
                        className="hover:text-[#8B5A2B] transition-colors"
                      >
                        +7 (495) 123-45-67
                      </a>
                    </li>
                    <li>
                      <a
                        href="mailto:hello@aroma.coffee"
                        className="hover:text-[#8B5A2B] transition-colors"
                      >
                        hello@aroma.coffee
                      </a>
                    </li>
                    <li className="text-sm text-[#8B5A2B]">
                      Instagram: @aroma.coffee
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-2xl overflow-hidden shadow-md border border-[#E8D5C4] min-h-[400px] flex flex-col">
            <div className="bg-[#E8D5C4]/60 flex-1 flex items-center justify-center p-8 relative">
              <div className="text-center">
                <div className="text-5xl mb-4">🗺️</div>
                <p className="text-[#2C1810] font-semibold mb-1">
                  Карта загружается...
                </p>
                <p className="text-sm text-[#6B4423] max-w-xs mx-auto">
                  ул. Кофейная, 15, Москва
                  <br />
                  (заглушка карты — в реальном проекте здесь будет
                  интерактивная карта)
                </p>
              </div>
              <div className="absolute inset-4 border-2 border-dashed border-[#8B5A2B]/30 rounded-xl pointer-events-none" />
            </div>
            <div className="p-4 bg-[#FDF8F3] border-t border-[#E8D5C4] text-center text-sm text-[#6B4423]">
              Открыть в{" "}
              <a
                href="https://yandex.ru/maps"
                target="_blank"
                rel="noopener noreferrer"
                className="text-[#8B5A2B] font-medium hover:underline"
              >
                Яндекс.Картах
              </a>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
