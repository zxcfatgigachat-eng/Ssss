import Link from "next/link";

export default function NotFound() {
  return (
    <div className="max-w-lg mx-auto px-4 py-24 text-center">
      <h1 className="text-6xl font-bold text-[#2C1810] mb-4">404</h1>
      <p className="text-[#6B4423] mb-8">Страница не найдена</p>
      <Link
        href="/"
        className="inline-flex items-center gap-2 bg-[#2C1810] text-[#F5E6D3] font-semibold px-6 py-3 rounded-full hover:bg-[#4A2F23] transition-colors"
      >
        На главную
      </Link>
    </div>
  );
}
