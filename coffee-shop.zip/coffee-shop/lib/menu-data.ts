export type MenuItem = {
  id: string;
  name: string;
  price: number;
  description: string;
  category: "coffee" | "tea" | "dessert" | "food";
  image: string;
};

export const menuItems: MenuItem[] = [
  {
    id: "1",
    name: "Эспрессо",
    price: 180,
    description: "Классический крепкий эспрессо из свежеобжаренных зёрен. Насыщенный вкус с нотками шоколада и карамели.",
    category: "coffee",
    image: "https://images.unsplash.com/photo-1510591509098-f4fdc6d0e954?w=600&h=400&fit=crop",
  },
  {
    id: "2",
    name: "Капучино",
    price: 250,
    description: "Идеальный баланс эспрессо, молока и воздушной пенки. Классика итальянской кофейной культуры.",
    category: "coffee",
    image: "https://images.unsplash.com/photo-1572442388796-11668a67e53d?w=600&h=400&fit=crop",
  },
  {
    id: "3",
    name: "Латте",
    price: 280,
    description: "Нежный кофе с большим количеством вспененного молока. Можно добавить сироп на выбор.",
    category: "coffee",
    image: "https://images.unsplash.com/photo-1561882468-9110e03e0f78?w=600&h=400&fit=crop",
  },
  {
    id: "4",
    name: "Флэт Уайт",
    price: 270,
    description: "Двойной эспрессо с бархатистым микро-пеной. Более насыщенный вкус, чем у латте.",
    category: "coffee",
    image: "https://images.unsplash.com/photo-1447933601403-0c6688de566e?w=600&h=400&fit=crop",
  },
  {
    id: "5",
    name: "Раф-кофе",
    price: 320,
    description: "Фирменный раф на ванильном сиропе со сливками. Нежный, сладкий и очень ароматный.",
    category: "coffee",
    image: "https://images.unsplash.com/photo-1461023058949-1ceec1b710c4?w=600&h=400&fit=crop",
  },
  {
    id: "6",
    name: "Чай Матча Латте",
    price: 290,
    description: "Японский зелёный чай матча со вспененным молоком. Энергия и антиоксиданты в одной чашке.",
    category: "tea",
    image: "https://images.unsplash.com/photo-1536013551178-d8d1e289a2e4?w=600&h=400&fit=crop",
  },
  {
    id: "7",
    name: "Чёрный чай с бергамотом",
    price: 190,
    description: "Классический эрл грей с нотками бергамота. Подаётся с лимоном или молоком по желанию.",
    category: "tea",
    image: "https://images.unsplash.com/photo-1576092768241-dec231879fc3?w=600&h=400&fit=crop",
  },
  {
    id: "8",
    name: "Круассан с миндалём",
    price: 220,
    description: "Свежий французский круассан с миндальной начинкой и хрустящей корочкой.",
    category: "dessert",
    image: "https://images.unsplash.com/photo-1555507036-ab1f4038808a?w=600&h=400&fit=crop",
  },
  {
    id: "9",
    name: "Чизкейк Нью-Йорк",
    price: 350,
    description: "Нежный классический чизкейк на песочной основе с ягодным соусом.",
    category: "dessert",
    image: "https://images.unsplash.com/photo-1533134242443-d4fd215305ad?w=600&h=400&fit=crop",
  },
  {
    id: "10",
    name: "Авокадо-тост",
    price: 380,
    description: "Цельнозерновой тост с размятым авокадо, яйцом пашот, микрозеленью и семенами чиа.",
    category: "food",
    image: "https://images.unsplash.com/photo-1525351484163-7529414344d8?w=600&h=400&fit=crop",
  },
  {
    id: "11",
    name: "Овсяная каша с ягодами",
    price: 290,
    description: "Тёплая овсянка на растительном молоке с сезонными ягодами, мёдом и орехами.",
    category: "food",
    image: "https://images.unsplash.com/photo-1517673400267-0251440c45dc?w=600&h=400&fit=crop",
  },
  {
    id: "12",
    name: "Брауни с мороженым",
    price: 310,
    description: "Шоколадный брауни собственного приготовления, подаётся с шариком ванильного мороженого.",
    category: "dessert",
    image: "https://images.unsplash.com/photo-1606313564200-e75d5e30476c?w=600&h=400&fit=crop",
  },
];

export function getMenuItem(id: string): MenuItem | undefined {
  return menuItems.find((item) => item.id === id);
}

export const categoryLabels: Record<MenuItem["category"], string> = {
  coffee: "Кофе",
  tea: "Чай",
  dessert: "Десерты",
  food: "Еда",
};
